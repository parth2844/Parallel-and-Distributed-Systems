/*

    Submitted By:
    Ritwick Verma     83006696
    Parth Shah        54809514
    
    To compile and run:
    g++ main.c math-mult.c -lpthread -o main && ./main

*/

#include "mat-mult.h"
#include <stdio.h> //just to print stuff in screen
#include <time.h>
#include <pthread.h>

pthread_mutex_t lock;
int s;
int *a, *b, *c;
int i=0;

// This function fills a row of the matrix c using matrices a and b. Unfolded on i.
void mat_mult(int x)
{
    for(int j=0;j<s;j++)
    {
        for(int k=0;k<s;k++)
        {
            *(c+x*s+j) += *(a+x*s+k) * *(b+k*s+j);
        }
    }
}

// This is the main function that represents each thread
void *thread()
{
    long x=i;

    // execute till global i reaches row size. 
    // Thus, the thread that finishes executing first will get the next i 
    // and increase it so that next thread gets up to date i.
    while(i<=s)
    {   
        // obtain mutex lock and increase the global i
        pthread_mutex_lock(&lock);
        x=i;
        i++;
        pthread_mutex_unlock(&lock);

        if(x>=s)    break;
        
        // Multiply matrices
        mat_mult(x);
    }

    pthread_exit(0);
}

// Function that creates MAX_THREAD threads and then waits for their completion.
void driver(int MAX_THREADS)
{
    pthread_mutex_init(&lock, NULL);
    pthread_t tid[MAX_THREADS];

    // spawn threads
    for(long i=0; i<MAX_THREADS; i++)
    {
        int err=pthread_create(&tid[i],NULL, thread, NULL);
        if(err!=0)  printf("error");
    }

    // calling join will pause the main thread till the execution of the argument thread is not complete.
    for(long i=0;i<MAX_THREADS;i++)
    {
        pthread_join(tid[i],NULL);
    }
}

void multiply(int* mat_ptr, int threads, int size){

    struct timespec start, end;
    double elapsed;
    s=size;
    a=mat_ptr;
    b=(a+s*s);
    c=(b+s*s);

    // note start time
    clock_gettime(CLOCK_MONOTONIC, &start);
    // driver thread that spawns threads and joins them after their completion
    driver(threads);  
    // note end time
    clock_gettime(CLOCK_MONOTONIC, &end);
    
    elapsed = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1000000000.0;
    printf("%0.4lf\n",elapsed);
    

    return elapsed;
}
