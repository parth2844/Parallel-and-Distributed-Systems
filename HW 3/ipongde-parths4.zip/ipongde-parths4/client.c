/* Client Code */

#include <netdb.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#define PORT 4000

int main()
{ 
    int sock, cli; 
    struct sockaddr_in server;
    char* msg = "Hello World!";
  
    //Socket creation
    sock = socket(AF_INET, SOCK_STREAM, 0); 

    //Socket Verification
    if (sock == -1) { 
        printf("Socket Creation Failed!\n"); 
        exit(-1); 
    } 
    else
       printf("Socket Created!\n"); 
  
    // Assigning the IP and PORT of the server
    server.sin_family = AF_INET;  
    server.sin_port = htons(PORT); 
    if(inet_pton(AF_INET, "192.168.0.83", &server.sin_addr) <= 0){
        printf("Invalid addr\n");
        exit(-1);
    }
  
    // Connecting Client Socket to the Server Socket
    if (connect(sock, (struct sockaddr *)&server, sizeof(server)) == -1){ 
        printf("Server connection failed!\n"); 
        exit(-1); 
    } 
    else
        printf("Connected to Server\n"); 
   
    
    send(sock, msg, strlen(msg), 0); 
    close(sock); 
} 