/* Server Code */

#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<errno.h>
#define PORT 4000

int main()

{
            int sock, cli;
            int len;
            int opt = 1; 
            struct sockaddr_in server, client;
            char buffer[256] = {0};

            //Socket Creation
            sock = socket(AF_INET, SOCK_STREAM, 0);

            //Socket Verification
            if(sock == -1)
            {
                printf("Socket Creation Failed!");
                exit(-1);
            }

            //Assigning Server IP and PORT information
            server.sin_family = AF_INET;
            server.sin_port = htons(PORT);
            server.sin_addr.s_addr = htonl(INADDR_ANY);

            //Binding socket to given IP
            if((bind(sock, (struct sockaddr *)&server, sizeof(struct sockaddr_in))) == -1)
            {
                printf("Error in Binding\n");
                exit(-1);
            }

            //Server starts listening
             if((listen(sock, 5)) == -1)
            {
                printf("Error in Listening\n");
                exit(-1);
            }
            else
                printf("Server Started Listening\n");
            
            len = sizeof(client);

            //Accept packet from client
            cli = accept(sock, (struct sockaddr *)&client, &len);
            if(cli == -1){
                printf("Error in Accepting");
                exit(-1);
            }
            
            //Read information from client to buffer
            read(cli, buffer, 256); 
    
            printf("Received msg from client: %s \n", buffer); 
            close(sock);

}